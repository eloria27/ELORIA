ELORIA BY SUAIB — Android APK build package

ফোন দিয়েই APK বানানোর সহজ পদ্ধতি (GitHub Actions):

১) GitHub অ্যাকাউন্টে সাইন ইন করে New repository তৈরি করুন।
২) Repository-তে এই ZIP-এর ভেতরের ELORIA_Android_Project ফোল্ডারের সব ফাইল আপলোড করুন।
   গুরুত্বপূর্ণ: .github ফোল্ডারটিও আপলোড করবেন। ZIP ফাইলটি সরাসরি repository-তে রেখে দিলে হবে না।
৩) আপলোড শেষে Actions ট্যাবে যান। "Build ELORIA Android APK" workflow নির্বাচন করুন।
৪) Run workflow চাপুন। Build শেষ হলে workflow run-এর নিচে Artifacts থেকে
   "ELORIA-debug-APK" ডাউনলোড করুন।
৫) ZIP artifact খুলে app-debug.apk বের করুন। Android ফোনে APK-তে চাপ দিয়ে ইনস্টল করুন।
   Android চাইলে Settings থেকে ওই অ্যাপ/ব্রাউজারের জন্য "Install unknown apps" অনুমতি দিন।
   ইনস্টল শেষে নিরাপত্তার জন্য অনুমতিটি বন্ধ করে দিতে পারেন।

যদি Actions ট্যাব না দেখায়, repository-র Settings > Actions থেকে Actions অনুমোদন আছে কি না দেখুন।

গুরুত্বপূর্ণ:
- এই ZIP নিজে APK নয়; GitHub-এর cloud build-এ APK তৈরি হবে।
- এটি debug APK, Play Store release-এর জন্য signed release build নয়।
- বর্তমান অ্যাপের PIN 8071।
- অর্ডার/পণ্য ডেটা লোকাল WebView স্টোরেজে থাকতে পারে; বহু ডিভাইসের জন্য cloud database লাগবে।
- bKash/Nagad payment auto-verification নেই; Transaction ID ম্যানুয়ালি যাচাই করতে হবে।
